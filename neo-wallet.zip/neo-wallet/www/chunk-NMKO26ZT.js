var o=n=>{let s=n.classList.contains("ion-touched"),c=n.classList.contains("ion-invalid");return s&&c};export{o as a};
