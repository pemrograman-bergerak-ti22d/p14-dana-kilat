import {
  AddressType,
  BarcodeFormat,
  BarcodeValueType,
  EmailFormatType,
  GoogleBarcodeScannerModuleInstallState,
  LensFacing,
  PhoneFormatType,
  Resolution,
  WifiEncryptionType,
  registerPlugin
} from "./chunk-IZAJSLLA.js";
import "./chunk-UL2P3LPA.js";

// node_modules/@capacitor-mlkit/barcode-scanning/dist/esm/index.js
var BarcodeScanner = registerPlugin("BarcodeScanner", {
  web: () => import("./web-VZ6NTYYU.js").then((m) => new m.BarcodeScannerWeb())
});
export {
  AddressType,
  BarcodeFormat,
  BarcodeScanner,
  BarcodeValueType,
  EmailFormatType,
  GoogleBarcodeScannerModuleInstallState,
  LensFacing,
  PhoneFormatType,
  Resolution,
  WifiEncryptionType
};
//# sourceMappingURL=@capacitor-mlkit_barcode-scanning.js.map
