import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
// GANTI QRCodeModule menjadi QRCodeComponent di sini
import { QRCodeComponent } from 'angularx-qrcode'; 

@Component({
  selector: 'app-merchant', 
  templateUrl: './merchant.page.html',
  styleUrls: ['./merchant.page.scss'], 
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule, QRCodeComponent], 
})

export class MerchantPage {
  storeName: string = "Cyber Coffee";
  price: number = 0;
  generatedQR: string = "";

  createInvoice() {
    const invoice = {
      merchant: this.storeName,
      harga: this.price
    };
    this.generatedQR = JSON.stringify(invoice);
  }
}