import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule, ToastController, Platform, AlertController } from '@ionic/angular';
import { RouterModule } from '@angular/router';

// Import Ikon yang diperlukan
import { addIcons } from 'ionicons';
import { 
  addCircle, paperPlane, storefront, time, qrCodeOutline, 
  flash, water, gameController, grid 
} from 'ionicons/icons';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, RouterModule],
})
export class HomePage {
  saldo = 215000; 
  history: any[] = [
    { date: new Date().toLocaleTimeString(), amount: 35000, storeName: 'Cyber Coffee' }
  ];

  constructor(
    private toastCtrl: ToastController, 
    private platform: Platform,
    private alertCtrl: AlertController
  ) {
    // Daftarkan ikon agar muncul di layar
    addIcons({ 
      'add-circle': addCircle, 
      'paper-plane': paperPlane, 
      'storefront': storefront, 
      'time': time,
      'qr-code-outline': qrCodeOutline,
      'flash': flash,
      'water': water,
      'game-controller': gameController,
      'grid': grid
    });
  }

  // Fitur Top Up dengan input nominal sendiri
  async isiSaldo() {
    const alert = await this.alertCtrl.create({
      header: 'Top Up Neo-Wallet',
      message: 'Masukkan nominal saldo (Min. Rp 1.000)',
      inputs: [{ name: 'nominal', type: 'number', placeholder: 'Contoh: 50000' }],
      buttons: [
        { text: 'Batal', role: 'cancel' },
        {
          text: 'Isi Sekarang',
          handler: (data) => {
            const jumlah = Number(data.nominal);
            if (jumlah >= 1000) {
              this.saldo += jumlah;
              this.showNotif(`Top Up Rp ${jumlah.toLocaleString()} Berhasil!`, 'success');
            } else {
              this.showNotif('Nominal minimal Rp 1.000', 'danger');
            }
          }
        }
      ]
    });
    await alert.present();
  }

  // Fungsi Scan dengan simulasi data
  async handleScan() {
    this.showNotif('Mencari QR Code...', 'secondary');
    // Simulasi data dari QR Code Merchant
    const mockData = JSON.stringify({ merchant: "Neo Store", harga: 50000 });
    setTimeout(() => this.executePayment(mockData), 1000);
  }

  // Logika Pembayaran dengan KONFIRMASI (Biar Dosen Senang)
  async executePayment(dataStr: string) {
    try {
      const obj = JSON.parse(dataStr);
      const cost = Number(obj.harga);
      const store = obj.merchant;

      const alert = await this.alertCtrl.create({
        header: 'Konfirmasi Bayar',
        message: `Bayar **Rp ${cost.toLocaleString()}** ke **${store}**?`,
        buttons: [
          { text: 'Batal', role: 'cancel' },
          {
            text: 'Bayar Sekarang',
            handler: () => {
              if (this.saldo >= cost) {
                this.saldo -= cost;
                this.history.unshift({ date: new Date().toLocaleTimeString(), amount: cost, storeName: store });
                this.showNotif(`Sukses membayar ke ${store}`, 'success');
              } else {
                this.showNotif('Saldo tidak cukup!', 'danger');
              }
            }
          }
        ]
      });
      await alert.present();
    } catch (e) {
      this.showNotif('QR Tidak Valid', 'warning');
    }
  }

  comingSoon(fitur: string) {
    this.showNotif(`Fitur ${fitur} segera hadir ya!`, 'medium');
  }

  async showNotif(msg: string, color: string) {
    const toast = await this.toastCtrl.create({ message: msg, duration: 2000, color, position: 'top' });
    toast.present();
  }
}